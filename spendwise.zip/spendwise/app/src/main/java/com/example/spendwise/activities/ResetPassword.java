package com.example.spendwise.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ResetPassword extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}